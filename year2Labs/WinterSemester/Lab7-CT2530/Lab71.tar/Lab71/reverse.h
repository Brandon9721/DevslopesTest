void reverse(char*, char*);
