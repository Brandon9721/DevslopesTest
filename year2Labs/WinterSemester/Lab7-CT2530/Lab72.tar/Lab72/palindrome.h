int palindrome(char* word);
